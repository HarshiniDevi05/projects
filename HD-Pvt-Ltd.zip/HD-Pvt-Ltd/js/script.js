const canvas = document.getElementById("networkCanvas");

if(canvas){

    const ctx = canvas.getContext("2d");

    let particles = [];
let mouse = {

    x: null,

    y: null,

    radius: 120

};
    function resizeCanvas(){

        canvas.width = window.innerWidth;

        canvas.height = window.innerHeight;

    }

    resizeCanvas();
window.addEventListener("mousemove", (e)=>{

    mouse.x = e.x;

    mouse.y = e.y;

});

window.addEventListener("mouseleave", ()=>{

    mouse.x = null;

    mouse.y = null;

});
    window.addEventListener("resize", () => {

        resizeCanvas();

        createParticles();

    });

    function createParticles(){

        particles = [];

        // Fewer particles on mobile
        const totalParticles =

window.innerWidth <= 768 ? 35 : 80;

        for(let i = 0; i < totalParticles; i++){

            particles.push({

                x:Math.random() * canvas.width,

                y:Math.random() * canvas.height,

                radius:Math.random() * 2 + 1,

                speedX:(Math.random()-0.5)*0.5,

                speedY:(Math.random()-0.5)*0.5,

                color:[
                    "#00D9FF",
                    "#8B5CF6",
                    "#EC4899"
                ][Math.floor(Math.random()*3)]

            });

        }

    }

    createParticles();
function animate(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    particles.forEach(p=>{

        p.x += p.speedX;
        p.y += p.speedY;
// Mouse Attraction

if(mouse.x !== null){

    const dx = mouse.x - p.x;

    const dy = mouse.y - p.y;

    const distance = Math.sqrt(dx * dx + dy * dy);

    if(distance < mouse.radius){

        p.x += dx * 0.002;

        p.y += dy * 0.002;

    }

}
        if(p.x < 0 || p.x > canvas.width)
            p.speedX *= -1;

        if(p.y < 0 || p.y > canvas.height)
            p.speedY *= -1;

        ctx.beginPath();

        ctx.arc(
            p.x,
            p.y,
            p.radius,
            0,
            Math.PI*2
        );

        ctx.fillStyle = p.color;

        ctx.shadowBlur = 12;

        ctx.shadowColor = p.color;

        ctx.fill();

        ctx.shadowBlur = 0;

    });
//==========================
// Connect Nearby Particles
//==========================

for(let i = 0; i < particles.length; i++){

    for(let j = i + 1; j < particles.length; j++){

        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;

        const distance = Math.sqrt(dx * dx + dy * dy);

        if(distance < 140){

            const opacity = 1 - (distance / 140);

            ctx.beginPath();

            ctx.strokeStyle = `rgba(0,217,255,${opacity * 0.35})`;

            ctx.lineWidth = 1;

            ctx.moveTo(
                particles[i].x,
                particles[i].y
            );

            ctx.lineTo(
                particles[j].x,
                particles[j].y
            );

            ctx.stroke();

        }

    }

}
    requestAnimationFrame(animate);

}

animate();
}
/*==================================
        MOBILE NAVBAR
===================================*/

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

if(menuToggle && navLinks){

    menuToggle.addEventListener("click", () => {

        navLinks.classList.toggle("active");

        const icon = menuToggle.querySelector("i");

        if(navLinks.classList.contains("active")){

            icon.classList.remove("fa-bars");
            icon.classList.add("fa-times");

        }else{

            icon.classList.remove("fa-times");
            icon.classList.add("fa-bars");

        }

    });

    document.querySelectorAll(".nav-links a").forEach(link => {

        link.addEventListener("click", () => {

            navLinks.classList.remove("active");

            const icon = menuToggle.querySelector("i");

            icon.classList.remove("fa-times");
            icon.classList.add("fa-bars");

        });

    });

}
/*=====================================
        NAVBAR SCROLL EFFECT
=====================================*/

const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", () => {

    if(window.scrollY > 50){

        navbar.classList.add("scrolled");

    }else{

        navbar.classList.remove("scrolled");

    }

});
/*=====================================
        HERO TEXT SLIDER
=====================================*/

const changingText = document.getElementById("changingText");

const words = [

    "Software Solutions",

    "AI Applications",

    "Cloud Technology",

    "Mobile Applications",

    "Digital Transformation"

];

let currentWord = 0;

if(changingText){

    setInterval(()=>{

        changingText.style.opacity = 0;

        setTimeout(()=>{

            currentWord++;

            if(currentWord >= words.length){

                currentWord = 0;

            }

            changingText.textContent = words[currentWord];

            changingText.style.opacity = 1;

        },500);

    },3500);

}
/*=====================================
        SERVICE CARD
=====================================*/

const plusButtons = document.querySelectorAll(".plus");

plusButtons.forEach(button=>{

    button.addEventListener("click",()=>{

        const card = button.closest(".service-card");

        card.classList.toggle("active");

        button.textContent =
            card.classList.contains("active")
            ? "−"
            : "+";

    });

});
/*=====================================
        COUNTER ANIMATION
=====================================*/

const counters = document.querySelectorAll(".counter");

const startCounters = () => {

    counters.forEach(counter => {

        const target = Number(counter.dataset.target);

        let count = 0;

        const increment = target / 100;

        const update = () => {

            count += increment;

            if(count < target){

                counter.textContent = Math.ceil(count);

                requestAnimationFrame(update);

            }else{

                counter.textContent = target;

            }

        };

        update();

    });

};

startCounters();
/*=====================================
            FAQ
=====================================*/

const faqItems = document.querySelectorAll(".faq-item");

faqItems.forEach(item=>{

    const button = item.querySelector(".faq-question");
    const icon = button.querySelector("span");

    button.addEventListener("click",()=>{

        faqItems.forEach(faq=>{

            if(faq !== item){

                faq.classList.remove("active");

                faq.querySelector("span").textContent = "+";

            }

        });

        item.classList.toggle("active");

        icon.textContent = item.classList.contains("active")
            ? "−"
            : "+";

    });

});