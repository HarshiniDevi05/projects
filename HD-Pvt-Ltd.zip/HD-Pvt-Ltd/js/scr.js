const canvas = document.getElementById("networkCanvas");

if (canvas) {

    const ctx = canvas.getContext("2d");

    let mouse = {
        x: null,
        y: null
    };

    let mouseRadius = 120;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    window.addEventListener("mousemove", (event) => {
        mouse.x = event.x;
        mouse.y = event.y;
    });

    // Create particles

    // Animate function

    // animate();

    window.addEventListener("mouseleave", () => {
        mouse.x = null;
        mouse.y = null;
    });

// <-- Close the if ONLY after all canvas code is finished
// Create dots

let particles = [];


for(let i = 0; i < 80; i++){

   particles.push({

    x: Math.random() * canvas.width,

    y: Math.random() * canvas.height,

    size: Math.random()*3+1,

    speedX:(Math.random()-0.5)*0.5,

    speedY:(Math.random()-0.5)*0.5,

    color:[
        "#00D9FF",
        "#8B5CF6",
        "#EC4899"
    ][Math.floor(Math.random()*3)]

});

}



// Draw animation

function animate(){

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


particles.forEach(p=>{


    // Move dots

    p.x += p.speedX;
    p.y += p.speedY;
// Mouse interaction

if(mouse.x !== null && mouse.y !== null){

    let dx = mouse.x - p.x;

    let dy = mouse.y - p.y;


    let distance = Math.sqrt(
        dx * dx + dy * dy
    );


    if(distance < mouseRadius){

      p.x += dx * 0.0015;
p.y += dy * 0.0015;
    }

}

    // Bounce

    if(p.x < 0 || p.x > canvas.width)
        p.speedX *= -1;


    if(p.y < 0 || p.y > canvas.height)
        p.speedY *= -1;



    // Draw dots

    ctx.beginPath();

    ctx.arc(
        p.x,
        p.y,
        p.size,
        0,
        Math.PI * 2
    );


   ctx.shadowBlur = 20;

ctx.shadowColor = p.color;


ctx.fillStyle = p.color;

ctx.fill();


ctx.shadowBlur = 0;


});
// Draw connecting lines

for(let a = 0; a < particles.length; a++){

    for(let b = a + 1; b < particles.length; b++){


        let dx = particles[a].x - particles[b].x;

        let dy = particles[a].y - particles[b].y;


        let distance = Math.sqrt(
            dx*dx + dy*dy
        );


       const connectDistance =
window.innerWidth < 768 ? 100 : 150;

if(distance < connectDistance){

            let opacity = 1 - distance/150;


            ctx.beginPath();


           ctx.strokeStyle =
`rgba(0,217,255,${opacity * 0.5})`;


            ctx.lineWidth = 1;


            ctx.moveTo(
                particles[a].x,
                particles[a].y
            );


            ctx.lineTo(
                particles[b].x,
                particles[b].y
            );


            ctx.stroke();

        }

    }


}

    requestAnimationFrame(animate);

}

animate();
window.addEventListener("mouseleave",()=>{

    mouse.x = null;

    mouse.y = null;

});
// Hero Text Slider

const words = [

    "Software Solutions",

    "AI Applications",

    "Cloud Technology",

    "Mobile Applications",

    "Digital Transformation"

];


let wordIndex = 0;


const changingText =
document.getElementById("changingText");


setInterval(()=>{


    wordIndex++;


    if(wordIndex >= words.length){

        wordIndex = 0;

    }


    changingText.style.opacity = 0;


    setTimeout(()=>{


        changingText.innerHTML =
        words[wordIndex];


        changingText.style.opacity = 1;


    },500);



},4000);
// Scroll Reveal Animation

function revealSections() {

    const reveals = document.querySelectorAll(".reveal");

    reveals.forEach(section => {

        const windowHeight = window.innerHeight;
        const sectionTop = section.getBoundingClientRect().top;

        if (sectionTop < windowHeight - 100) {
            section.classList.add("active");
        }

    });

}

window.addEventListener("scroll", revealSections);

// Show sections already visible on page load
revealSections();
// Service Card Expand


const plusButtons =
document.querySelectorAll(".plus");


plusButtons.forEach(button=>{


    button.addEventListener("click",()=>{


        const card =
        button.parentElement;


        card.classList.toggle("active");


        button.innerHTML =
        card.classList.contains("active")
        ? "−"
        : "+";


    });


});
// Counter Animation

const counters =
document.querySelectorAll(".counter");


counters.forEach(counter=>{


    counter.innerText="0";


    const updateCounter=()=>{


        const target =
        +counter.getAttribute("data-target");


        const current =
        +counter.innerText;


        const increment =
        target / 100;


        if(current < target){


            counter.innerText =
            Math.ceil(current + increment);


            setTimeout(updateCounter,20);


        }
        else{


            counter.innerText = target + "+";


        }


    };


    updateCounter();


});
const faqItems = document.querySelectorAll(".faq-item");

faqItems.forEach(item => {

    const question = item.querySelector(".faq-question");

    question.addEventListener("click", () => {

        faqItems.forEach(faq => {
            if (faq !== item) {
                faq.classList.remove("active");
            }
        });

        item.classList.toggle("active");

    });

});
// Contact Form Validation

const contactForm = document.getElementById("contactForm");

if(contactForm){

    contactForm.addEventListener("submit",function(e){

        e.preventDefault();

        const name=document.getElementById("name").value.trim();

        const email=document.getElementById("email").value.trim();

        const message=document.getElementById("message").value.trim();

        const formMessage=document.getElementById("formMessage");

        if(name==="" || email==="" || message===""){

            formMessage.style.color="#ff4d4d";

            formMessage.innerHTML="Please fill in all required fields.";

            return;

        }

        formMessage.style.color="#00d9ff";

        formMessage.innerHTML="✅ Thank you! Your message has been sent successfully.";

        contactForm.reset();

    });

}
/*==============================
      Payment Method Toggle
==============================*/

const paymentOptions = document.querySelectorAll('input[name="payment"]');

const cardFields = document.getElementById("cardFields");

const upiField = document.getElementById("upiField");

const paypalField = document.getElementById("paypalField");

if(paymentOptions.length){

    paymentOptions.forEach(option=>{

        option.addEventListener("change",()=>{

            cardFields.style.display="none";

            upiField.style.display="none";

            paypalField.style.display="none";

            if(option.value==="credit" || option.value==="debit"){

                cardFields.style.display="block";

            }

            else if(option.value==="upi"){

                upiField.style.display="block";

            }

            else if(option.value==="paypal"){

                paypalField.style.display="block";

            }

        });

    });

}
/*==============================
      Order Summary
==============================*/

const summaryPayment =
document.getElementById("summaryPayment");

const paymentRadios =
document.querySelectorAll('input[name="payment"]');

paymentRadios.forEach(radio=>{

    radio.addEventListener("change",()=>{

        if(radio.checked){

            summaryPayment.innerHTML =
            radio.parentElement.querySelector("h3").innerText;

        }

    });

});
const checkoutBtn =
document.getElementById("checkoutBtn");

if(checkoutBtn){

    checkoutBtn.addEventListener("click",()=>{

        const selectedPlan =
document.getElementById("summaryPlan").innerText;

window.location.href =
"success.html?plan=" +
encodeURIComponent(selectedPlan);

    });

}
/*==============================
      Plan Selection
==============================*/

const params = new URLSearchParams(window.location.search);

const plan = params.get("plan");
console.log(window.location.href);
console.log("Plan =", plan);
if(plan){

    const planIcon = document.getElementById("planIcon");
    const planName = document.getElementById("planName");
    const planDescription = document.getElementById("planDescription");

    const todayCharge = document.getElementById("todayCharge");
    const planDuration = document.getElementById("planDuration");
    const afterPlan = document.getElementById("afterPlan");

    const summaryPlan = document.getElementById("summaryPlan");
    const summaryPrice = document.getElementById("summaryPrice");
    const summaryToday = document.getElementById("summaryToday");
    const summaryTotal = document.getElementById("summaryTotal");

    if(plan === "startup"){

        planIcon.innerHTML = "🚀";

        planName.innerHTML = "Startup Plan";

        planDescription.innerHTML =
        "Perfect for startups and growing businesses.";

        todayCharge.innerHTML = "$499";

        todayCharge.classList.remove("free");

        planDuration.innerHTML = "Monthly";

        afterPlan.innerHTML = "Renews Every Month";

        summaryPlan.innerHTML = "Startup";

        summaryPrice.innerHTML = "$499 / Month";

        summaryToday.innerHTML = "$499";

        summaryTotal.innerHTML = "$499";

    }

    else if(plan === "business"){

        planIcon.innerHTML = "⚡";

        planName.innerHTML = "Business Plan";

        planDescription.innerHTML =
        "Advanced solutions for growing companies.";

        todayCharge.innerHTML = "$999";

        todayCharge.classList.remove("free");

        planDuration.innerHTML = "Monthly";

        afterPlan.innerHTML = "Renews Every Month";

        summaryPlan.innerHTML = "Business";

        summaryPrice.innerHTML = "$999 / Month";

        summaryToday.innerHTML = "$999";

        summaryTotal.innerHTML = "$999";

    }

    else if (plan === "trial") {

        planIcon.innerHTML = "🎁";

        planName.innerHTML = "14-Day Free Trial";

        planDescription.innerHTML =
        "Enjoy premium features free for 14 days.";

        todayCharge.innerHTML = "FREE";

        todayCharge.classList.add("free");

        planDuration.innerHTML = "14 Days";

        afterPlan.innerHTML = "Choose Any Plan";

        summaryPlan.innerHTML = "Free Trial";

        summaryPrice.innerHTML = "FREE";

        summaryToday.innerHTML = "$0.00";

        summaryTotal.innerHTML = "$0.00";

    }
else {

    console.log("Unknown plan:", plan);

}
}
/*=========================
      Success Page
==========================*/

const successPlan =
document.getElementById("successPlan");

if(successPlan){

    const params =
    new URLSearchParams(window.location.search);

    successPlan.innerHTML =
    params.get("plan") || "Free Trial";

}
}